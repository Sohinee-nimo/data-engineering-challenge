"""
HTML Report Generator
Produces a self-contained, interactive HTML dashboard embedding all EDA charts.
"""

import base64
import json
from pathlib import Path
from datetime import datetime
import pandas as pd


def img_b64(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def generate_report(df: pd.DataFrame, eda_result: dict, output_path: str = "output/report.html") -> str:
    charts = eda_result.get("charts", {})
    stats = eda_result.get("stats", {})
    insights = eda_result.get("insights", [])

    # Embed charts as base64
    chart_html = ""
    chart_titles = {
        "01_category_dist":     "Category Distribution",
        "02_price_hist":        "Price Distributions by Category",
        "03_price_boxplot":     "Price Range Comparison",
        "04_top_cities":        "Top Supplier Cities",
        "05_state_heatmap":     "State × Category Heatmap",
        "06_source_comparison": "Source Platform Comparison",
        "07_price_buckets":     "Price Buckets by Category",
        "08_keywords":          "Top Product Keywords",
        "09_ratings":           "Supplier Ratings",
        "10_quality":           "Data Quality Analysis",
        "11_timeline":          "Scrape Timeline",
    }
    for key, title in chart_titles.items():
        if key in charts and Path(charts[key]).exists():
            b64 = img_b64(charts[key])
            chart_html += f"""
            <div class="chart-card">
                <div class="chart-title">{title}</div>
                <img src="data:image/png;base64,{b64}" alt="{title}" loading="lazy"/>
            </div>"""

    # Insights HTML
    insights_html = "\n".join(
        f'<li class="insight-item">{ins.replace("**", "<strong>").replace("**", "</strong>")}</li>'
        for ins in insights
    )

    # Category table
    cat_rows = ""
    for cat, info in stats.get("price_by_category", {}).items():
        cat_rows += f"""
        <tr>
            <td><span class="cat-badge cat-{cat.lower().split()[0]}">{cat}</span></td>
            <td>{stats['category_breakdown'].get(cat, 0)}</td>
            <td>₹{info['median']:,.0f}</td>
            <td>₹{info['min']:,.0f}</td>
            <td>₹{info['max']:,.0f}</td>
        </tr>"""

    # City table
    city_rows = ""
    for city, count in list(stats.get("top_cities", {}).items())[:10]:
        city_rows += f"<tr><td>{city}</td><td>{count}</td></tr>"

    now = datetime.now().strftime("%B %d, %Y %H:%M")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>B2B Market Intelligence Report</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');

  :root {{
    --bg: #0D0F1A;
    --surface: #151824;
    --surface2: #1C2030;
    --border: #252840;
    --accent: #4F8EF7;
    --accent2: #E63946;
    --accent3: #4CAF50;
    --gold: #FFB300;
    --text: #E8EAF0;
    --muted: #7A7F9A;
    --radius: 14px;
  }}

  * {{ box-sizing: border-box; margin: 0; padding: 0; }}

  body {{
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    font-size: 15px;
    line-height: 1.6;
    min-height: 100vh;
  }}

  /* ── HERO ── */
  .hero {{
    background: linear-gradient(135deg, #0D0F1A 0%, #111730 50%, #0D1929 100%);
    border-bottom: 1px solid var(--border);
    padding: 64px 48px 48px;
    position: relative;
    overflow: hidden;
  }}
  .hero::before {{
    content: '';
    position: absolute;
    top: -120px; right: -120px;
    width: 480px; height: 480px;
    background: radial-gradient(circle, rgba(79,142,247,0.12) 0%, transparent 70%);
    pointer-events: none;
  }}
  .hero::after {{
    content: '';
    position: absolute;
    bottom: -80px; left: 20%;
    width: 320px; height: 320px;
    background: radial-gradient(circle, rgba(230,57,70,0.08) 0%, transparent 70%);
    pointer-events: none;
  }}
  .hero-tag {{
    display: inline-block;
    background: rgba(79,142,247,0.15);
    border: 1px solid rgba(79,142,247,0.4);
    color: var(--accent);
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 2px;
    text-transform: uppercase;
    padding: 4px 14px;
    border-radius: 20px;
    margin-bottom: 20px;
  }}
  .hero h1 {{
    font-family: 'Syne', sans-serif;
    font-size: clamp(28px, 4vw, 52px);
    font-weight: 800;
    line-height: 1.15;
    letter-spacing: -1px;
    margin-bottom: 12px;
  }}
  .hero h1 span {{ color: var(--accent); }}
  .hero-sub {{
    color: var(--muted);
    font-size: 16px;
    margin-bottom: 36px;
    max-width: 560px;
  }}
  .hero-meta {{
    display: flex;
    gap: 32px;
    flex-wrap: wrap;
    font-size: 13px;
    color: var(--muted);
  }}
  .hero-meta strong {{ color: var(--text); }}

  /* ── KPI GRID ── */
  .kpi-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    padding: 40px 48px;
  }}
  .kpi-card {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 24px 20px;
    position: relative;
    overflow: hidden;
    transition: transform 0.2s, border-color 0.2s;
  }}
  .kpi-card:hover {{ transform: translateY(-2px); border-color: var(--accent); }}
  .kpi-card::before {{
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: var(--kpi-color, var(--accent));
  }}
  .kpi-label {{
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 8px;
  }}
  .kpi-value {{
    font-family: 'Syne', sans-serif;
    font-size: 32px;
    font-weight: 700;
    color: var(--text);
    line-height: 1;
  }}
  .kpi-sub {{
    font-size: 12px;
    color: var(--muted);
    margin-top: 4px;
  }}

  /* ── LAYOUT ── */
  .container {{ padding: 0 48px 80px; }}
  
  .section-header {{
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 48px 0 24px;
  }}
  .section-header h2 {{
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 700;
  }}
  .section-line {{
    flex: 1;
    height: 1px;
    background: var(--border);
  }}
  .section-num {{
    font-size: 11px;
    font-weight: 600;
    color: var(--accent);
    letter-spacing: 2px;
  }}

  /* ── CHARTS ── */
  .charts-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(min(100%, 560px), 1fr));
    gap: 20px;
  }}
  .chart-card {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
    transition: transform 0.2s, box-shadow 0.2s;
  }}
  .chart-card:hover {{
    transform: translateY(-2px);
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  }}
  .chart-card.wide {{ grid-column: 1 / -1; }}
  .chart-title {{
    padding: 16px 20px 12px;
    font-family: 'Syne', sans-serif;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.5px;
    color: var(--muted);
    border-bottom: 1px solid var(--border);
  }}
  .chart-card img {{
    width: 100%;
    display: block;
    background: white;
  }}

  /* ── INSIGHTS ── */
  .insights-box {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 28px;
  }}
  .insights-box ul {{ list-style: none; display: flex; flex-direction: column; gap: 12px; }}
  .insight-item {{
    padding: 14px 18px;
    background: var(--surface2);
    border-radius: 10px;
    border-left: 3px solid var(--accent);
    font-size: 14px;
    line-height: 1.5;
  }}
  .insight-item strong {{ color: var(--accent); }}

  /* ── TABLES ── */
  .table-grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
  }}
  @media (max-width: 900px) {{ .table-grid {{ grid-template-columns: 1fr; }} }}
  .table-card {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
  }}
  .table-card-title {{
    padding: 16px 20px;
    font-family: 'Syne', sans-serif;
    font-size: 13px;
    font-weight: 700;
    border-bottom: 1px solid var(--border);
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 1px;
  }}
  table {{ width: 100%; border-collapse: collapse; }}
  th {{
    background: var(--surface2);
    padding: 10px 16px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--muted);
    text-align: left;
  }}
  td {{
    padding: 10px 16px;
    font-size: 13px;
    border-bottom: 1px solid rgba(255,255,255,0.04);
  }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover td {{ background: rgba(255,255,255,0.02); }}

  .cat-badge {{
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    background: rgba(79,142,247,0.15);
    color: var(--accent);
  }}

  /* ── FOOTER ── */
  footer {{
    border-top: 1px solid var(--border);
    padding: 24px 48px;
    color: var(--muted);
    font-size: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }}
</style>
</head>
<body>

<!-- HERO -->
<header class="hero">
  <div class="hero-tag">B2B Market Intelligence</div>
  <h1>India <span>B2B Marketplace</span><br/>Data Report</h1>
  <p class="hero-sub">Comprehensive analysis of product listings scraped from IndiaMART &amp; TradeIndia across 5 major industrial categories.</p>
  <div class="hero-meta">
    <div>Generated <strong>{now}</strong></div>
    <div>Total Listings <strong>{stats.get('total_products', 0):,}</strong></div>
    <div>Categories <strong>{stats.get('categories', 0)}</strong></div>
    <div>Cities Covered <strong>{stats.get('unique_cities', 0)}</strong></div>
  </div>
</header>

<!-- KPIs -->
<section class="kpi-grid">
  <div class="kpi-card" style="--kpi-color:#4F8EF7">
    <div class="kpi-label">Total Products</div>
    <div class="kpi-value">{stats.get('total_products', 0):,}</div>
    <div class="kpi-sub">Unique listings</div>
  </div>
  <div class="kpi-card" style="--kpi-color:#E63946">
    <div class="kpi-label">With Price</div>
    <div class="kpi-value">{stats.get('pct_with_price', 0):.0f}%</div>
    <div class="kpi-sub">{stats.get('products_with_price', 0):,} listings</div>
  </div>
  <div class="kpi-card" style="--kpi-color:#FFB300">
    <div class="kpi-label">Median Price</div>
    <div class="kpi-value">{'₹{:,.0f}'.format(stats['median_price_overall']) if stats.get('median_price_overall') else 'N/A'}</div>
    <div class="kpi-sub">All categories</div>
  </div>
  <div class="kpi-card" style="--kpi-color:#4CAF50">
    <div class="kpi-label">Verified Suppliers</div>
    <div class="kpi-value">{stats.get('verified_supplier_pct', 0):.0f}%</div>
    <div class="kpi-sub">Trust indicator</div>
  </div>
  <div class="kpi-card" style="--kpi-color:#9C27B0">
    <div class="kpi-label">Avg Rating</div>
    <div class="kpi-value">{stats.get('avg_rating', 0) or 0:.1f}<span style="font-size:18px;color:var(--muted)">/5</span></div>
    <div class="kpi-sub">Supplier quality</div>
  </div>
  <div class="kpi-card" style="--kpi-color:#00BCD4">
    <div class="kpi-label">States Covered</div>
    <div class="kpi-value">{stats.get('unique_states', 0)}</div>
    <div class="kpi-sub">Across India</div>
  </div>
</section>

<div class="container">

  <!-- KEY INSIGHTS -->
  <div class="section-header">
    <span class="section-num">01</span>
    <h2>Key Insights</h2>
    <div class="section-line"></div>
  </div>
  <div class="insights-box">
    <ul>{insights_html}</ul>
  </div>

  <!-- CHARTS -->
  <div class="section-header">
    <span class="section-num">02</span>
    <h2>Visualizations</h2>
    <div class="section-line"></div>
  </div>
  <div class="charts-grid">
    {chart_html}
  </div>

  <!-- TABLES -->
  <div class="section-header">
    <span class="section-num">03</span>
    <h2>Detailed Breakdowns</h2>
    <div class="section-line"></div>
  </div>
  <div class="table-grid">
    <div class="table-card">
      <div class="table-card-title">Category Summary</div>
      <table>
        <thead><tr><th>Category</th><th>Count</th><th>Median ₹</th><th>Min ₹</th><th>Max ₹</th></tr></thead>
        <tbody>{cat_rows}</tbody>
      </table>
    </div>
    <div class="table-card">
      <div class="table-card-title">Top Supplier Cities</div>
      <table>
        <thead><tr><th>City</th><th>Listings</th></tr></thead>
        <tbody>{city_rows}</tbody>
      </table>
    </div>
  </div>

</div>

<footer>
  <div>B2B Market Intelligence Pipeline — IndiaMART &amp; TradeIndia Analysis</div>
  <div>Generated {now}</div>
</footer>

</body>
</html>"""

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path
